// WRITE A C++ PROGRAM THAT WILL ASK FOR A TEMPERATURE IN FAHRENHEIT AND DISPLAY IT IN CLELCIUS

#include <iostream>
using namespace std;
int main()
{
    float fahrenheit, celsius;
    cout << "Enter temp in Fahrenheit : ";
    cin >> fahrenheit;
    celsius = (5.0 / 9.0) * (fahrenheit - 32);
    cout << "Temperature in celsius = " << celsius;
    return 0;
}