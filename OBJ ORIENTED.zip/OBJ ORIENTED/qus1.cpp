// WRITE  A PROGRAME TO DISPLAY THE FOLLOWING OUTPUT USING A SINGLE COUT STATEMENT

#include <iostream>
using namespace std;
int main()
{
    cout << "Maths = 90 \nPhysics = 77\nChemistry = 69";
    return 0;
}