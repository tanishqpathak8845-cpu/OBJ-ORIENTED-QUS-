// WRITE A PROGRAM TO READ THE VALUES OF A,B AND C AND DISPLAY THE VALUE OF X, WHERE X = A/B-C

#include <iostream>
using namespace std;
int main()
{
    float a, b, c, x;
    cout << "Enter value of a, b and c : ";
    cin >> a >> b >> c;
    x = a / b - c;
    cout << "Value of x = " << x;
    return 0;
}