// WRITE A PROGRAM THAT INPUT A CHAR. FROM KEYBOARD AND DISPLAY ITS CORRESPONDING ASCII VALUE ON THE SCREEN

#include <iostream>
using namespace std;
int main()
{
    char ch;
    cout << "Enter char : ";
    cin >> ch;

    cout << "ASCII value = " << int(ch);
    return 0;
}