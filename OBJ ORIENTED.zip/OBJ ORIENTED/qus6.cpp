//  REDO QUS NUMBER 5 USING A CLASS CALLED TEMP AND MEMBER FUNCTION 

#include <iostream>
using namespace std;
class Temp 
{
    float fahrenheit, celsius;
public:
    void getData()
    {
        cout << "Enter temp in fahernheit : ";
        cin >> fahrenheit;
    }
    void calculate()
    {
        celsius = (5.0 / 9.0 ) * (fahrenheit - 32 );
    }
    void display()
    {
        cout << "Temperture in celsius = " << celsius;
    }
};

int main(){
    Temp t;
    t.getData();
    t.calculate();
    t.display();
    return 0;
}